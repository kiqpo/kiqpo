def Builder(Content="", count=1,):
    List = ""
    for i in range(count):
        List += Content
    return List
