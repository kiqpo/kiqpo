def GetValue(Id):
    return f"""document.getElementById({Id}).value"""