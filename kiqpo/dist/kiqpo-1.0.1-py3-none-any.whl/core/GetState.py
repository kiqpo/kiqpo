def GetState(Id):
    return f'document.getElementById("{Id}").innerText'
