def img(src='',alt='img',classname=''):
    return f"""
    <img class='{classname}' src="{src}" alt='{alt}'' />
    """