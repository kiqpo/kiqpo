def ThisValue():
    return "this.value"