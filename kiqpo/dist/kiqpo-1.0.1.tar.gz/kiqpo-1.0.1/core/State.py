def State(Id, SetState):
    return f"document.getElementById('{Id}').innerText='{SetState}'"
